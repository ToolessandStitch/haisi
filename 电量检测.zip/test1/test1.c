
/*
 * Copyright (c) 2020 Nanjing Xiaoxiongpai Intelligent Technology Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "cmsis_os2.h"
#include "ohos_init.h"
#include "lwip/sockets.h"
#include "wifi_connect.h"

#include "iot_errno.h"
#include "iot_uart.h"

#include <hi_gpio.h>
#include <hi_early_debug.h>
#include <hi_io.h>
#include <hi_time.h>
#include <hi_watchdog.h>
#include <hi_task.h>
#include "iot_gpio.h"
#include "iot_gpio_ex.h"
#include "ssd1306.h"
//#include "iot_i2c.h"

//#include "E53_IA1.h"
#include "oc_mqtt.h"
#include <math.h>
//#include "iot_i2c_ex.h"

#define MSGQUEUE_COUNT 16 // number of Message Queue Objects
#define MSGQUEUE_SIZE 10
#define CLOUD_TASK_STACK_SIZE (1024 * 20)
#define CLOUD_TASK_PRIO 24
#define SENSOR_TASK_STACK_SIZE (1024 * 40)
#define SENSOR_TASK_PRIO 25
#define TASK_DELAY_3S 10

#define UART_BUFF_SIZE 20
#define WIFI_IOT_UART_IDX_1 1
#define IOT_I2C_IDX_BAUDRATE (400 * 1000)
#define SSD1306_I2C_IDX 0


typedef struct { // object data type
    char *Buf;
    uint8_t Idx;
} MSGQUEUE_OBJ_t;

MSGQUEUE_OBJ_t msg;
osMessageQueueId_t mid_MsgQueue; // message queue id

#define CLIENT_ID "toothless_Snorlax_0_0_2024070819"
#define USERNAME "toothless_Snorlax"
#define PASSWORD "a918e08a956f13ac6748de83d373ccc545d61f6531bb176e581f45c1f0575ad2"

typedef enum {
    en_msg_cmd = 0,
    en_msg_report,
} en_msg_type_t;

typedef struct {
    char *request_id;
    char *payload;
} cmd_t;

typedef struct {
    int I;
    int U;
    int P;
    int ELE;
} report_t;

typedef struct {
    en_msg_type_t msg_type;
    union {
        cmd_t cmd;
        report_t report;
    } msg;
} app_msg_t;

/* E53_IA1传感器数据类型定义 ------------------------------------------------------------*/
typedef struct {
    int electricity0;
    int voltage0;
    int power0;
    int electric_quantity0;
} DATA;

/*typedef struct {
    int connected;
    int led;
    int motor;
} app_cb_t;
static app_cb_t g_app_cb;*/


void GPIOInit(void)
{/*
     /*
     * 初始化I2C设备0，并指定波特率为400k
     * Initialize I2C device 0 and specify the baud rate as 400k
     */
    IoTI2cInit(SSD1306_I2C_IDX, IOT_I2C_IDX_BAUDRATE);
    /*
     * 设置I2C设备0的波特率为400k
     * Set the baud rate of I2C device 0 to 400k
     */
    IoTI2cSetBaudrate(SSD1306_I2C_IDX, IOT_I2C_IDX_BAUDRATE);
    /*
     * 设置GPIO13的管脚复用关系为I2C0_SDA
     * Set the pin reuse relationship of GPIO13 to I2C0_ SDA
     */
    IoSetFunc(IOT_IO_NAME_GPIO_13, IOT_IO_FUNC_GPIO_13_I2C0_SDA);
    /*
     * 设置GPIO14的管脚复用关系为I2C0_SCL
     * Set the pin reuse relationship of GPIO14 to I2C0_ SCL
     */
    IoSetFunc(IOT_IO_NAME_GPIO_14, IOT_IO_FUNC_GPIO_14_I2C0_SCL);
    
    hi_io_set_func(HI_IO_NAME_GPIO_5,HI_IO_FUNC_GPIO_5_UART1_RXD);//GPIO5 USART1_RXD
    hi_io_set_func(HI_IO_NAME_GPIO_6,HI_IO_FUNC_GPIO_6_UART1_TXD);//GPIO6 USART1_TXD
}

static void ReportMsg(report_t *report)
{
    oc_mqtt_profile_service_t service;
    oc_mqtt_profile_kv_t I;
    oc_mqtt_profile_kv_t U;
    oc_mqtt_profile_kv_t P;
    oc_mqtt_profile_kv_t ELE;
    //oc_mqtt_profile_kv_t motor;

    service.event_time = NULL;
    service.service_id = "toothless_Snorlax_service_id";
    service.service_property = &U;
    service.nxt = NULL;

    U.key = "U";
    U.value = &report->U;
    U.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    U.nxt = &I;

    I.key = "I";
    I.value = &report->I;
    I.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    I.nxt = &P;


    P.key = "P";
    P.value = &report->P;
    P.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    P.nxt = &ELE;

    ELE.key = "ELE";
    ELE.value = &report->ELE;
    ELE.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    ELE.nxt = NULL;


    oc_mqtt_profile_propertyreport(USERNAME, &service);
    return 0;
}//推送数据



static int CloudMainTaskEntry(void)
{
    app_msg_t *app_msg;

    uint32_t ret = WifiConnect("HONOR 70", "inbdcmmcjnz4dmu");

    device_info_init(CLIENT_ID, USERNAME, PASSWORD);
    oc_mqtt_init();
    //oc_set_cmd_rsp_cb(MsgRcvCallback);
    
    ssd1306_ClearOLED();
    ssd1306_SetCursor(0, 10); // x轴坐标为25，y轴坐标为10
    ssd1306_DrawString("I:",Font_7x10, White);
    ssd1306_SetCursor(0, 20); // x轴坐标为25，y轴坐标为10
    ssd1306_DrawString("U:", Font_7x10, White);
    ssd1306_SetCursor(0, 30); // x轴坐标为25，y轴坐标为10
    ssd1306_DrawString("P:", Font_7x10, White);
    ssd1306_SetCursor(0, 40); // x轴坐标为25，y轴坐标为10
    ssd1306_DrawString("ELE:", Font_7x10, White);
    ssd1306_UpdateScreen();

    while (1) {
       
        app_msg = NULL;
        (void)osMessageQueueGet(mid_MsgQueue, (void **)&app_msg, NULL, 0U);
        if (app_msg != NULL) {
            //switch (app_msg->msg_type) {
                //case en_msg_cmd:
                    //DealCmdMsg(&app_msg->msg.cmd);
                   // break;
                //case en_msg_report:
                    ReportMsg(&app_msg->msg.report);
                   // break;
               // default:
                   // break;
            //}
            free(app_msg);
        }
    }
    return 0;
}

static int SensorTaskEntry(void)
{  
    GPIOInit();
    ssd1306_Init();
    int i=0;
    int j=0;
    int uart_buff[UART_BUFF_SIZE] = { 0 };
    //char uart_buff1[UART_BUFF_SIZE] = {'8','9','0','9','9','3','0','8','8','0','9','7','3','0','8','7','5','9','8','3','0','8','8','5','9','9','3','0','8','9','0','9','9','3','0'};
    char *uart_buff_ptr=uart_buff;
    uint8_t ret;
    app_msg_t *app_msg;
    DATA Data;
    
    IotUartAttribute uart_attr = {
        // baud_rate: 9600
        .baudRate = 9600,
        // data_bits: 8bits
        .dataBits = 8,
        .stopBits = 1,
        .parity = 0,
    };

    // Initialize uart driver
    ret = IoTUartInit(WIFI_IOT_UART_IDX_1, &uart_attr);
    if (ret != IOT_SUCCESS) {
        printf("Failed to init uart! Err code = %d\n", ret);
        return;
    }

    while (1) {
        IoTUartRead(WIFI_IOT_UART_IDX_1, uart_buff_ptr, UART_BUFF_SIZE);
        app_msg = malloc(sizeof(app_msg_t));
        ssd1306_UpdateScreen();
        //IoTUartRead(WIFI_IOT_UART_IDX_1, &Data, UART_BUFF_SIZE);     
            //IoTUartRead(WIFI_IOT_UART_IDX_1, uart_buff_ptr, UART_BUFF_SIZE);
            app_msg->msg_type = en_msg_report;
            //switch (a)
            //{
            //case 0:
                ssd1306_SetCursor(0, 10); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawString("U:",Font_7x10, White);
                ssd1306_SetCursor(15, 10); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawChar(uart_buff[j],Font_7x10, White);
                 /*j++;
                ssd1306_SetCursor(20, 10); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawChar(uart_buff1[j],Font_7x10, White);
                ssd1306_UpdateScreen();*/
                Data.electricity0=uart_buff[i];
                app_msg->msg.report.U = (int)Data.electricity0;
                //break;
            //case 1:
                i++;
                j++;
                ssd1306_SetCursor(0, 20); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawString("I:", Font_7x10, White);
                ssd1306_SetCursor(15, 20); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawChar(uart_buff[j], Font_7x10, White);
                 j++;
                ssd1306_SetCursor(20, 20); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawChar(uart_buff[j], Font_7x10, White);
                 /*j++;
                ssd1306_SetCursor(25, 20); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawChar(uart_buff1[j], Font_7x10, White);
                ssd1306_UpdateScreen();*/
                Data.voltage0= uart_buff[i];
                app_msg->msg.report.I = (int)Data.voltage0;
               // break;
           // case 2:
                i++;
                j++;
                ssd1306_SetCursor(0, 30); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawString("P:", Font_7x10, White);
                ssd1306_SetCursor(15, 30); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawChar(uart_buff[j], Font_7x10, White);
                 j++;
                ssd1306_SetCursor(23, 30); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawChar(uart_buff[j], Font_7x10, White);
                /* j++;
                ssd1306_SetCursor(28, 30); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawChar(uart_buff1[j], Font_7x10, White);
                ssd1306_UpdateScreen();*/
                Data.power0= uart_buff[i];
                app_msg->msg.report.P = (int)Data.power0;
                //break;
           // case 3:
                i++;
                j++;
                ssd1306_SetCursor(0, 40); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawString("ELE:", Font_7x10, White);
                ssd1306_SetCursor(28, 40); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawChar(uart_buff[j],Font_7x10, White);
                 j++;
                ssd1306_SetCursor(35, 40); // x轴坐标为25，y轴坐标为10
                ssd1306_DrawChar(uart_buff[j],Font_7x10, White);
                ssd1306_UpdateScreen();
                Data.electric_quantity0= uart_buff[i];
                app_msg->msg.report.ELE =(int)Data.electric_quantity0;
               // break;
           // default :
               // break;
           // }
           // memset(uart_buff,0,i);
        if (osMessageQueuePut(mid_MsgQueue, &app_msg, 0U, 0U) != 0) 
        {
            free(app_msg);
        }
         i++;
          j++;
        if(i>20)
            i=0;
        if(j>40)
            j=0;
    
        /*for(i=0;i<4;i++)
        {
            IoTUartRead(WIFI_IOT_UART_IDX_1, uart_buff_ptr, UART_BUFF_SIZE);
             sprintf(mag,"I:%s\n", uart_buff_ptr);
            ssd1306_SetCursor(0, 10*i); // x轴坐标为25，y轴坐标为10
            ssd1306_DrawString(msg, Font_7x10, White);
            ssd1306_UpdateScreen();
            //printf("Uart1 read data:%s\n", uart_buff_ptr);
        }*/
        //memset(uart_buff_ptr,0,1000);
        //*uart_buff_ptr = uart_buff;
        //memset(uart_buff,0,4);
        usleep(TASK_DELAY_3S);
    }
    return 0;
}

static void IotMainTaskEntry(void)
{
    mid_MsgQueue = osMessageQueueNew(MSGQUEUE_COUNT, MSGQUEUE_SIZE, NULL);
    if (mid_MsgQueue == NULL) {
        printf("Failed to create Message Queue!\n");
    }

    osThreadAttr_t attr;

    attr.name = "CloudMainTaskEntry";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = CLOUD_TASK_STACK_SIZE;
    attr.priority = CLOUD_TASK_PRIO;

    if (osThreadNew((osThreadFunc_t)CloudMainTaskEntry, NULL, &attr) == NULL) {
        printf("Failed to create CloudMainTaskEntry!\n");
    }
    attr.stack_size = SENSOR_TASK_STACK_SIZE;
    attr.priority = SENSOR_TASK_PRIO;
    attr.name = "SensorTaskEntry";
    if (osThreadNew((osThreadFunc_t)SensorTaskEntry, NULL, &attr) == NULL) {
        printf("Failed to create SensorTaskEntry!\n");
    }
}

APP_FEATURE_INIT(IotMainTaskEntry);